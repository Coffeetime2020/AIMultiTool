import SwiftUI
import AVKit
import UIKit

// MARK: - Main App

struct AIMultiToolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

// MARK: - Main Content View

struct ContentView: View {
    @State private var selectedFeature: Feature? = nil
    
    enum Feature: String, CaseIterable, Identifiable {
        case faceAging = "AI Face Aging"
        case youtubeDownload = "YouTube Video Download"
        case webSearch = "Web Search"
        case scriptToMovie = "AI Script to Movie"
        case hairRemoval = "AI Hair Removal"
        
        var id: String { self.rawValue }
        
        var iconName: String {
            switch self {
            case .faceAging: return "person.crop.rectangle"
            case .youtubeDownload: return "arrow.down.circle"
            case .webSearch: return "magnifyingglass"
            case .scriptToMovie: return "film"
            case .hairRemoval: return "scissors"
            }
        }
        
        var description: String {
            switch self {
            case .faceAging: return "See how you might look when you're older using AI"
            case .youtubeDownload: return "Download videos from YouTube"
            case .webSearch: return "Search the web with AI assistance"
            case .scriptToMovie: return "Convert text scripts into animated movies"
            case .hairRemoval: return "Remove unwanted hair from photos using AI"
            }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                Text("AI Multi-Tool")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                
                Text("Select a feature to use:")
                    .font(.headline)
                    .padding(.bottom)
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(Feature.allCases) { feature in
                        FeatureButton(feature: feature) {
                            selectedFeature = feature
                        }
                    }
                }
                .padding()
                
                Spacer()
            }
            .sheet(item: $selectedFeature) { feature in
                getFeatureView(for: feature)
            }
            .navigationBarTitle("AI Multi-Tool", displayMode: .inline)
        }
    }
    
    @ViewBuilder
    private func getFeatureView(for feature: Feature) -> some View {
        switch feature {
        case .faceAging:
            FaceAgingView()
        case .youtubeDownload:
            YouTubeDownloadView()
        case .webSearch:
            WebSearchView()
        case .scriptToMovie:
            ScriptToMovieView()
        case .hairRemoval:
            HairRemovalView()
        }
    }
}

// MARK: - Feature Button

struct FeatureButton: View {
    let feature: ContentView.Feature
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: feature.iconName)
                    .font(.system(size: 30))
                    .foregroundColor(.blue)
                    .frame(height: 60)
                
                Text(feature.rawValue)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                
                Text(feature.description)
                    .font(.caption)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding()
            .frame(maxWidth: .infinity, minHeight: 160)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white)
                    .shadow(color: .gray.opacity(0.3), radius: 5, x: 0, y: 2)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Models and API Result Types

enum APIResult<T, E: Error> {
    case success(T)
    case failure(E)
}

struct ProgressUpdate {
    let progress: Double // 0.0 to 1.0
    let message: String
}

enum FeatureType {
    case faceAging
    case youtubeDownload
    case webSearch
    case scriptToMovie
    case hairRemoval
}

enum ProcessingQuality: String, CaseIterable, Identifiable {
    case low = "Low"
    case medium = "Medium"
    case high = "High"
    
    var id: String { self.rawValue }
    
    var description: String {
        switch self {
        case .low:
            return "Faster processing, lower quality"
        case .medium:
            return "Balanced speed and quality"
        case .high:
            return "Best quality, slower processing"
        }
    }
}

// MARK: - Image Picker

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.presentationMode) private var presentationMode
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        // No updates needed
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let editedImage = info[.editedImage] as? UIImage {
                parent.image = editedImage
            } else if let originalImage = info[.originalImage] as? UIImage {
                parent.image = originalImage
            }
            
            parent.presentationMode.wrappedValue.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}

// MARK: - API Keys Helper

struct APIKeys {
    // Retrieve API keys from environment variables or use fallback demo keys
    static let faceAgingAPI = ProcessInfo.processInfo.environment["FACE_AGING_API_KEY"] ?? "demo_face_aging_key"
    static let youtubeAPI = ProcessInfo.processInfo.environment["YOUTUBE_API_KEY"] ?? "demo_youtube_key"
    static let webSearchAPI = ProcessInfo.processInfo.environment["WEB_SEARCH_API_KEY"] ?? "demo_search_key"
    static let scriptToMovieAPI = ProcessInfo.processInfo.environment["SCRIPT_TO_MOVIE_API_KEY"] ?? "demo_script_movie_key"
    static let hairRemovalAPI = ProcessInfo.processInfo.environment["HAIR_REMOVAL_API_KEY"] ?? "demo_hair_removal_key"
}

// MARK: - Face Aging Feature

struct FaceAgingView: View {
    @StateObject private var viewModel = FaceAgingViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var showingImagePicker = false
    @State private var sliderValue: Double = 20
    @State private var processingImage = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    Text("AI Face Aging")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("Upload a portrait photo and see how you might look as you age")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                    
                    if viewModel.inputImage != nil {
                        Image(uiImage: viewModel.inputImage!)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .cornerRadius(10)
                            .padding()
                    } else {
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 200)
                            
                            VStack {
                                Image(systemName: "photo")
                                    .font(.system(size: 40))
                                Text("No Image Selected")
                                    .font(.headline)
                            }
                            .foregroundColor(.gray)
                        }
                        .padding()
                    }
                    
                    Button(action: {
                        showingImagePicker = true
                    }) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                            Text(viewModel.inputImage == nil ? "Select Photo" : "Change Photo")
                        }
                        .frame(minWidth: 200)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    if viewModel.inputImage != nil {
                        VStack(alignment: .leading) {
                            Text("Age Adjustment: \(Int(sliderValue)) years")
                                .font(.headline)
                            
                            Slider(value: $sliderValue, in: 5...70, step: 5)
                                .padding(.vertical)
                            
                            Button(action: {
                                processingImage = true
                                viewModel.processImage(targetAge: Int(sliderValue)) { success in
                                    processingImage = false
                                }
                            }) {
                                HStack {
                                    if processingImage {
                                        ProgressView()
                                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                            .padding(.trailing, 5)
                                    } else {
                                        Image(systemName: "wand.and.stars")
                                    }
                                    Text(processingImage ? "Processing..." : "Generate Aged Photo")
                                }
                                .frame(minWidth: 200)
                                .padding()
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                            }
                            .disabled(processingImage)
                        }
                        .padding()
                    }
                    
                    if viewModel.resultImage != nil {
                        VStack {
                            Text("Result")
                                .font(.headline)
                            
                            Image(uiImage: viewModel.resultImage!)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 200)
                                .cornerRadius(10)
                                .padding()
                            
                            Button(action: {
                                viewModel.saveResultImage()
                            }) {
                                HStack {
                                    Image(systemName: "square.and.arrow.down")
                                    Text("Save to Photos")
                                }
                                .frame(minWidth: 200)
                                .padding()
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                            }
                        }
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(image: $viewModel.inputImage)
            }
            .alert(isPresented: $viewModel.showingAlert) {
                Alert(
                    title: Text(viewModel.alertTitle),
                    message: Text(viewModel.alertMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
            .navigationBarItems(leading: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                }
            })
        }
    }
}

class FaceAgingViewModel: ObservableObject {
    @Published var inputImage: UIImage?
    @Published var resultImage: UIImage?
    @Published var showingAlert = false
    @Published var alertTitle = ""
    @Published var alertMessage = ""
    
    private let faceAgingService = FaceAgingService()
    
    func processImage(targetAge: Int, completion: @escaping (Bool) -> Void) {
        guard let image = inputImage else {
            showAlert(title: "Error", message: "No image selected")
            completion(false)
            return
        }
        
        faceAgingService.ageFace(image: image, targetAge: targetAge) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let processedImage):
                    self?.resultImage = processedImage
                    completion(true)
                case .failure(let error):
                    self?.showAlert(title: "Processing Error", message: error.localizedDescription)
                    completion(false)
                }
            }
        }
    }
    
    func saveResultImage() {
        guard let image = resultImage else {
            showAlert(title: "Error", message: "No result image to save")
            return
        }
        
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveCompleted), nil)
    }
    
    @objc func saveCompleted(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            showAlert(title: "Save Error", message: error.localizedDescription)
        } else {
            showAlert(title: "Saved", message: "Image has been saved to your photos")
        }
    }
    
    private func showAlert(title: String, message: String) {
        alertTitle = title
        alertMessage = message
        showingAlert = true
    }
}

class FaceAgingService {
    enum FaceAgingError: Error {
        case invalidImage
        case processingFailed
        case apiError(String)
        case networkError
        
        var localizedDescription: String {
            switch self {
            case .invalidImage:
                return "The image is invalid or corrupted."
            case .processingFailed:
                return "Failed to process the image."
            case .apiError(let message):
                return "API Error: \(message)"
            case .networkError:
                return "Network connection error. Please check your internet connection."
            }
        }
    }
    
    // In a real implementation, this would use an actual API key from environment variables
    private let apiKey = APIKeys.faceAgingAPI
    
    func ageFace(image: UIImage, targetAge: Int, completion: @escaping (Result<UIImage, FaceAgingError>) -> Void) {
        // Compress and convert the image to base64
        guard let imageData = image.jpegData(compressionQuality: 0.7) else {
            completion(.failure(.invalidImage))
            return
        }
        
        let base64Image = imageData.base64EncodedString()
        
        // For demo purposes, we'll simulate the API call and return a processed version of the input image
        // In a real implementation, this would make an actual API request to a face aging service
        simulateAPICall(originalImage: image, base64Image: base64Image, targetAge: targetAge, completion: completion)
    }
    
    private func simulateAPICall(originalImage: UIImage, base64Image: String, targetAge: Int, completion: @escaping (Result<UIImage, FaceAgingError>) -> Void) {
        // Simulate network delay
        DispatchQueue.global().asyncAfter(deadline: .now() + 2.0) {
            // For demonstration purposes, apply a filter to the original image to simulate aging
            if let processedImage = self.applyAgingFilter(to: originalImage, age: targetAge) {
                completion(.success(processedImage))
            } else {
                completion(.failure(.processingFailed))
            }
        }
    }
    
    private func applyAgingFilter(to image: UIImage, age: Int) -> UIImage? {
        // This is a simplified simulation of face aging
        // Real implementation would use the API response
        
        // Create a CIImage from the UIImage
        guard let ciImage = CIImage(image: image) else { return nil }
        
        // Create a filter based on the target age
        var filter: CIFilter?
        let intensity = Float(age) / 100.0
        
        if age < 30 {
            // Younger - slight smoothing
            filter = CIFilter(name: "CIHighlightShadowAdjust")
            filter?.setValue(ciImage, forKey: kCIInputImageKey)
            filter?.setValue(intensity * 0.5, forKey: "inputHighlightAmount")
            filter?.setValue(intensity * 0.2, forKey: "inputShadowAmount")
        } else if age < 50 {
            // Middle aged - slight sepia and contrast
            filter = CIFilter(name: "CISepiaTone")
            filter?.setValue(ciImage, forKey: kCIInputImageKey)
            filter?.setValue(intensity * 0.3, forKey: kCIInputIntensityKey)
        } else {
            // Older - stronger sepia, more contrast and sharpness
            let sepiaFilter = CIFilter(name: "CISepiaTone")
            sepiaFilter?.setValue(ciImage, forKey: kCIInputImageKey)
            sepiaFilter?.setValue(intensity * 0.4, forKey: kCIInputIntensityKey)
            
            guard let sepiaOutput = sepiaFilter?.outputImage else { return nil }
            
            filter = CIFilter(name: "CIHighlightShadowAdjust")
            filter?.setValue(sepiaOutput, forKey: kCIInputImageKey)
            filter?.setValue(1.0 + (intensity * 0.3), forKey: "inputHighlightAmount")
            filter?.setValue(1.0 - (intensity * 0.3), forKey: "inputShadowAmount")
        }
        
        // Get the output CIImage
        guard let outputCIImage = filter?.outputImage else { return nil }
        
        // Convert CIImage to UIImage
        let context = CIContext()
        guard let cgImage = context.createCGImage(outputCIImage, from: outputCIImage.extent) else { return nil }
        
        return UIImage(cgImage: cgImage)
    }
}

// MARK: - YouTube Video Download Feature

struct YouTubeDownloadView: View {
    @StateObject private var viewModel = YouTubeDownloadViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var videoURL = ""
    @State private var selectedQuality = "720p"
    
    let availableQualities = ["360p", "480p", "720p", "1080p"]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    Text("YouTube Video Downloader")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("Enter a YouTube video URL to download")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                    
                    TextField("YouTube URL", text: $videoURL)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.gray.opacity(0.1))
                        )
                        .padding(.horizontal)
                    
                    HStack {
                        Text("Quality:")
                            .font(.headline)
                        
                        Picker("Quality", selection: $selectedQuality) {
                            ForEach(availableQualities, id: \.self) { quality in
                                Text(quality).tag(quality)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                    .padding(.horizontal)
                    
                    if viewModel.thumbnailImage != nil {
                        VStack {
                            Text("Video Preview")
                                .font(.headline)
                            
                            Image(uiImage: viewModel.thumbnailImage!)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 180)
                                .cornerRadius(8)
                            
                            if !viewModel.videoTitle.isEmpty {
                                Text(viewModel.videoTitle)
                                    .font(.headline)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                            }
                            
                            if !viewModel.videoDuration.isEmpty {
                                Text("Duration: \(viewModel.videoDuration)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding()
                    }
                    
                    Button(action: {
                        if viewModel.state == .idle || viewModel.state == .error {
                            viewModel.getVideoInfo(from: videoURL)
                        }
                    }) {
                        HStack {
                            if viewModel.state == .loading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .padding(.trailing, 5)
                            } else {
                                Image(systemName: "info.circle")
                            }
                            Text(viewModel.state == .loading ? "Loading..." : "Get Video Info")
                        }
                        .frame(minWidth: 200)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(videoURL.isEmpty || viewModel.state == .loading)
                    
                    if viewModel.state == .ready {
                        Button(action: {
                            viewModel.downloadVideo(from: videoURL, quality: selectedQuality)
                        }) {
                            HStack {
                                if viewModel.state == .downloading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                        .padding(.trailing, 5)
                                } else {
                                    Image(systemName: "arrow.down.circle")
                                }
                                Text(viewModel.state == .downloading ? "Downloading..." : "Download Video")
                            }
                            .frame(minWidth: 200)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }
                        .disabled(viewModel.state == .downloading)
                    }
                    
                    if viewModel.downloadProgress > 0 && viewModel.downloadProgress < 1.0 {
                        VStack {
                            ProgressView(value: viewModel.downloadProgress)
                                .padding(.horizontal)
                            
                            Text("\(Int(viewModel.downloadProgress * 100))%")
                                .font(.caption)
                                .padding(.top, 5)
                        }
                    }
                    
                    if let downloadedURL = viewModel.downloadedFileURL {
                        VStack {
                            Text("Download Complete!")
                                .font(.headline)
                                .foregroundColor(.green)
                            
                            if downloadedURL.pathExtension.lowercased() == "mp4" {
                                VideoPlayer(player: AVPlayer(url: downloadedURL))
                                    .frame(height: 200)
                                    .cornerRadius(8)
                                    .padding()
                            }
                            
                            Button(action: {
                                viewModel.saveVideoToPhotos()
                            }) {
                                HStack {
                                    Image(systemName: "square.and.arrow.down")
                                    Text("Save to Photos")
                                }
                                .frame(minWidth: 200)
                                .padding()
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                            }
                        }
                    }
                    
                    if viewModel.state == .error {
                        Text(viewModel.errorMessage)
                            .foregroundColor(.red)
                            .padding()
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .alert(isPresented: $viewModel.showingAlert) {
                Alert(
                    title: Text(viewModel.alertTitle),
                    message: Text(viewModel.alertMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
            .navigationBarItems(leading: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                }
            })
        }
    }
}

class YouTubeDownloadViewModel: ObservableObject {
    enum DownloadState {
        case idle, loading, ready, downloading, complete, error
    }
    
    @Published var state: DownloadState = .idle
    @Published var thumbnailImage: UIImage?
    @Published var videoTitle: String = ""
    @Published var videoDuration: String = ""
    @Published var downloadProgress: Double = 0
    @Published var downloadedFileURL: URL?
    @Published var errorMessage: String = ""
    @Published var showingAlert = false
    @Published var alertTitle = ""
    @Published var alertMessage = ""
    
    private let youtubeService = YouTubeService()
    
    func getVideoInfo(from url: String) {
        guard !url.isEmpty else { return }
        
        state = .loading
        youtubeService.getVideoInfo(from: url) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let videoInfo):
                    self?.thumbnailImage = videoInfo.thumbnail
                    self?.videoTitle = videoInfo.title
                    self?.videoDuration = videoInfo.duration
                    self?.state = .ready
                case .failure(let error):
                    self?.state = .error
                    self?.errorMessage = "Error: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func downloadVideo(from url: String, quality: String) {
        guard state == .ready else { return }
        
        state = .downloading
        downloadProgress = 0
        
        youtubeService.downloadVideo(from: url, quality: quality) { [weak self] progress in
            DispatchQueue.main.async {
                self?.downloadProgress = progress
            }
        } completion: { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let fileURL):
                    self?.downloadedFileURL = fileURL
                    self?.state = .complete
                case .failure(let error):
                    self?.state = .error
                    self?.errorMessage = "Download failed: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func saveVideoToPhotos() {
        guard let url = downloadedFileURL else {
            showAlert(title: "Error", message: "No video to save")
            return
        }
        
        youtubeService.saveVideoToPhotos(url: url) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.showAlert(title: "Save Error", message: error.localizedDescription)
                } else {
                    self?.showAlert(title: "Success", message: "Video saved to your photo library")
                }
            }
        }
    }
    
    private func showAlert(title: String, message: String) {
        alertTitle = title
        alertMessage = message
        showingAlert = true
    }
}

class YouTubeService {
    enum YouTubeServiceError: Error {
        case invalidURL
        case downloadFailed
        case fileWriteFailed
        case networkError
        case invalidResponse
        case noVideoInfo
        
        var localizedDescription: String {
            switch self {
            case .invalidURL:
                return "The YouTube URL is invalid."
            case .downloadFailed:
                return "Failed to download the video."
            case .fileWriteFailed:
                return "Failed to save the video file."
            case .networkError:
                return "Network connection error. Please check your internet connection."
            case .invalidResponse:
                return "Received an invalid response from the server."
            case .noVideoInfo:
                return "Could not retrieve video information."
            }
        }
    }
    
    struct VideoInfo {
        let title: String
        let thumbnail: UIImage
        let duration: String
    }
    
    // In a real implementation, this would use an actual API key from environment variables
    private let apiKey = APIKeys.youtubeAPI
    
    func getVideoInfo(from url: String, completion: @escaping (Result<VideoInfo, YouTubeServiceError>) -> Void) {
        // Validate the URL
        guard let _ = URL(string: url), url.contains("youtube.com") || url.contains("youtu.be") else {
            completion(.failure(.invalidURL))
            return
        }
        
        // For demo purposes, we'll simulate the API call and return a dummy video info
        // In a real implementation, this would make an actual API request to YouTube's API
        simulateVideoInfoAPICall(url: url, completion: completion)
    }
    
    func downloadVideo(from url: String, quality: String, progressHandler: @escaping (Double) -> Void, completion: @escaping (Result<URL, YouTubeServiceError>) -> Void) {
        // Validate the URL
        guard let _ = URL(string: url), url.contains("youtube.com") || url.contains("youtu.be") else {
            completion(.failure(.invalidURL))
            return
        }
        
        // For demo purposes, we'll simulate downloading a video and return a local video file
        // In a real implementation, this would make an actual download request
        simulateVideoDownload(url: url, quality: quality, progressHandler: progressHandler, completion: completion)
    }
    
    func saveVideoToPhotos(url: URL, completion: @escaping (Error?) -> Void) {
        // In a real implementation, this would use PHPhotoLibrary to save the video
        // For demo purposes, we'll simulate saving the video
        DispatchQueue.global().asyncAfter(deadline: .now() + 1.0) {
            completion(nil) // Simulate successful save
        }
    }
    
    // MARK: - Private Simulation Methods
    
    private func simulateVideoInfoAPICall(url: String, completion: @escaping (Result<VideoInfo, YouTubeServiceError>) -> Void) {
        // Simulate network delay
        DispatchQueue.global().asyncAfter(deadline: .now() + 1.5) {
            // Extract video ID from URL for demonstration purposes
            let videoID = self.extractVideoID(from: url) ?? "dQw4w9WgXcQ" // Default to a known video ID if extraction fails
            
            // Create a dummy image for thumbnail
            let thumbnailImage = self.createDummyThumbnail(videoID: videoID)
            
            // Create video info
            let videoInfo = VideoInfo(
                title: "Sample YouTube Video - \(videoID)",
                thumbnail: thumbnailImage,
                duration: "4:20"
            )
            
            completion(.success(videoInfo))
        }
    }
    
    private func simulateVideoDownload(url: String, quality: String, progressHandler: @escaping (Double) -> Void, completion: @escaping (Result<URL, YouTubeServiceError>) -> Void) {
        // Simulate download progress updates
        var progress: Double = 0.0
        let timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { timer in
            progress += 0.05
            progressHandler(min(progress, 0.95))
            
            if progress >= 1.0 {
                timer.invalidate()
            }
        }
        
        // Simulate download completion after delay
        DispatchQueue.global().asyncAfter(deadline: .now() + 4.0) {
            timer.invalidate()
            progressHandler(1.0)
            
            // In a real implementation, we would save the downloaded video to a temporary file
            // For demo purposes, we'll just create a dummy video file URL
            if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                let videoFilename = "youtube_video_\(Int(Date().timeIntervalSince1970)).mp4"
                let videoFileURL = documentsDirectory.appendingPathComponent(videoFilename)
                
                // Simulate file creation (in a real app, we would write actual video data)
                // Here, we're just pretending the file exists
                completion(.success(videoFileURL))
            } else {
                completion(.failure(.fileWriteFailed))
            }
        }
    }
    
    // Helper function to extract YouTube video ID from URL
    private func extractVideoID(from url: String) -> String? {
        if url.contains("youtube.com/watch") {
            // Extract from standard YouTube URL
            if let queryItems = URLComponents(string: url)?.queryItems {
                return queryItems.first(where: { $0.name == "v" })?.value
            }
        } else if url.contains("youtu.be/") {
            // Extract from shortened YouTube URL
            if let range = url.range(of: "youtu.be/") {
                let startIndex = range.upperBound
                if let endIndex = url[startIndex...].firstIndex(where: { $0 == "?" || $0 == "&" || $0 == "#" }) {
                    return String(url[startIndex..<endIndex])
                } else {
                    return String(url[startIndex...])
                }
            }
        }
        return nil
    }
    
    // Create a dummy thumbnail image with the video ID
    private func createDummyThumbnail(videoID: String) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 320, height: 180))
        
        return renderer.image { ctx in
            // Draw background
            UIColor.darkGray.setFill()
            ctx.fill(CGRect(x: 0, y: 0, width: 320, height: 180))
            
            // Draw play button
            let playButtonRect = CGRect(x: 135, y: 65, width: 50, height: 50)
            UIColor.white.setFill()
            UIBezierPath(ovalIn: playButtonRect).fill()
            
            UIColor.red.setFill()
            let trianglePath = UIBezierPath()
            trianglePath.move(to: CGPoint(x: 150, y: 75))
            trianglePath.addLine(to: CGPoint(x: 175, y: 90))
            trianglePath.addLine(to: CGPoint(x: 150, y: 105))
            trianglePath.close()
            trianglePath.fill()
            
            // Draw video ID as text
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 16),
                .foregroundColor: UIColor.white
            ]
            
            let displayID = "Video ID: \(videoID.prefix(10))..."
            let textRect = CGRect(x: 10, y: 150, width: 300, height: 20)
            displayID.draw(in: textRect, withAttributes: attributes)
        }
    }
}

// MARK: - Web Search Feature

struct WebSearchView: View {
    @StateObject private var viewModel = WebSearchViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var searchQuery = ""
    
    var body: some View {
        NavigationView {
            VStack {
                Text("AI-Powered Web Search")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.top)
                
                Text("Search the web with AI-enhanced results")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .padding(.bottom)
                
                HStack {
                    TextField("Search the web...", text: $searchQuery)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.gray.opacity(0.1))
                        )
                    
                    Button(action: {
                        if !searchQuery.isEmpty {
                            viewModel.performSearch(query: searchQuery)
                        }
                    }) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .disabled(searchQuery.isEmpty || viewModel.isLoading)
                }
                .padding(.horizontal)
                
                if viewModel.isLoading {
                    VStack {
                        Spacer()
                        ProgressView("Searching...")
                            .progressViewStyle(CircularProgressViewStyle())
                        Spacer()
                    }
                } else if !viewModel.searchResults.isEmpty {
                    List {
                        // AI Summary Section
                        if let summary = viewModel.aiSummary, !summary.isEmpty {
                            Section(header: Text("AI Summary")) {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text(summary)
                                        .font(.body)
                                }
                                .padding(.vertical, 8)
                            }
                        }
                        
                        // Search Results Section
                        Section(header: Text("Web Results")) {
                            ForEach(viewModel.searchResults) { result in
                                SearchResultView(result: result) {
                                    viewModel.openWebPage(url: result.url)
                                }
                            }
                        }
                    }
                    .listStyle(InsetGroupedListStyle())
                } else if viewModel.hasSearched {
                    VStack {
                        Spacer()
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 50))
                            .foregroundColor(.gray)
                        Text("No results found")
                            .font(.headline)
                            .padding()
                        Text("Try a different search term")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Spacer()
                    }
                } else {
                    VStack {
                        Spacer()
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 50))
                            .foregroundColor(.gray)
                        Text("Enter a search term above")
                            .font(.headline)
                            .padding()
                        Text("Results will appear here")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Spacer()
                    }
                }
            }
            .padding(.top)
            .navigationBarItems(leading: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                }
            })
            .alert(isPresented: $viewModel.showingError) {
                Alert(
                    title: Text("Error"),
                    message: Text(viewModel.errorMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
            .sheet(isPresented: $viewModel.showingWebView) {
                if let url = viewModel.webViewURL {
                    SafariWebView(url: url)
                }
            }
        }
    }
}

struct SearchResultView: View {
    let result: SearchResult
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Text(result.title)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .lineLimit(2)
                
                Text(result.url)
                    .font(.caption)
                    .foregroundColor(.blue)
                    .lineLimit(1)
                
                Text(result.description)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .lineLimit(3)
            }
            .padding(.vertical, 6)
        }
    }
}

struct SafariWebView: UIViewControllerRepresentable {
    let url: URL
    
    func makeUIViewController(context: Context) -> UIViewController {
        let safariVC = SFSafariViewController(url: url)
        return safariVC
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
    
    // This would typically use SFSafariViewController, but we'll just declare it
    // for the sake of the example as it requires importing SafariServices
    typealias SFSafariViewController = UIViewController
}

class WebSearchViewModel: ObservableObject {
    @Published var searchResults: [SearchResult] = []
    @Published var aiSummary: String? = nil
    @Published var isLoading = false
    @Published var hasSearched = false
    @Published var showingError = false
    @Published var errorMessage = ""
    @Published var showingWebView = false
    @Published var webViewURL: URL? = nil
    
    private let webSearchService = WebSearchService()
    
    func performSearch(query: String) {
        isLoading = true
        searchResults = []
        aiSummary = nil
        
        webSearchService.search(query: query) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                self?.hasSearched = true
                
                switch result {
                case .success(let searchResponse):
                    self?.searchResults = searchResponse.results
                    self?.aiSummary = searchResponse.aiSummary
                case .failure(let error):
                    self?.showError(message: error.localizedDescription)
                }
            }
        }
    }
    
    func openWebPage(url: String) {
        guard let url = URL(string: url) else {
            showError(message: "Invalid URL")
            return
        }
        
        webViewURL = url
        showingWebView = true
    }
    
    private func showError(message: String) {
        errorMessage = message
        showingError = true
    }
}

struct SearchResult: Identifiable {
    let id = UUID()
    let title: String
    let url: String
    let description: String
}

class WebSearchService {
    enum WebSearchError: Error {
        case invalidQuery
        case requestFailed
        case networkError
        case parseError
        
        var localizedDescription: String {
            switch self {
            case .invalidQuery:
                return "The search query is invalid."
            case .requestFailed:
                return "Failed to complete the search request."
            case .networkError:
                return "Network connection error. Please check your internet connection."
            case .parseError:
                return "Failed to parse the search results."
            }
        }
    }
    
    struct SearchResponse {
        let results: [SearchResult]
        let aiSummary: String?
    }
    
    // In a real implementation, this would use an actual API key from environment variables
    private let apiKey = APIKeys.webSearchAPI
    
    func search(query: String, completion: @escaping (Result<SearchResponse, WebSearchError>) -> Void) {
        // Validate query
        guard !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            completion(.failure(.invalidQuery))
            return
        }
        
        // For demo purposes, we'll simulate the API call and return dummy search results
        // In a real implementation, this would make an actual API request to a search service
        simulateSearchAPICall(query: query, completion: completion)
    }
    
    // MARK: - Private Simulation Methods
    
    private func simulateSearchAPICall(query: String, completion: @escaping (Result<SearchResponse, WebSearchError>) -> Void) {
        // Simulate network delay
        DispatchQueue.global().asyncAfter(deadline: .now() + 1.5) {
            // Generate dummy search results based on the query
            let results = self.generateDummyResults(for: query)
            
            // Generate AI summary if there are results
            let aiSummary = !results.isEmpty ? self.generateAISummary(for: query, results: results) : nil
            
            let response = SearchResponse(results: results, aiSummary: aiSummary)
            completion(.success(response))
        }
    }
    
    private func generateDummyResults(for query: String) -> [SearchResult] {
        // Clean up the query for use in result generation
        let cleanQuery = query.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Generate a set of dummy results based on the query
        var results: [SearchResult] = []
        
        // Result 1: Wikipedia-style result
        results.append(
            SearchResult(
                title: "\(query.capitalized) - Wikipedia",
                url: "https://en.wikipedia.org/wiki/\(cleanQuery.replacingOccurrences(of: " ", with: "_"))",
                description: "Learn about \(query) on Wikipedia, the free encyclopedia. \(query.capitalized) refers to a concept that has numerous applications and interpretations across different contexts."
            )
        )
        
        // Result 2: News article
        results.append(
            SearchResult(
                title: "Latest News about \(query.capitalized)",
                url: "https://news.example.com/topics/\(cleanQuery.replacingOccurrences(of: " ", with: "-"))",
                description: "Stay up-to-date with the latest news and developments related to \(query). Our comprehensive coverage includes analysis, expert opinions, and more."
            )
        )
        
        // Result 3: Tutorial/How-to
        results.append(
            SearchResult(
                title: "How to Understand \(query.capitalized): A Complete Guide",
                url: "https://howto.example.com/guides/\(cleanQuery.replacingOccurrences(of: " ", with: "-"))",
                description: "This comprehensive guide explains everything you need to know about \(query). Learn from experts and master the topic with our step-by-step instructions."
            )
        )
        
        // Result 4: Video content
        results.append(
            SearchResult(
                title: "\(query.capitalized) Explained - Video Series",
                url: "https://videos.example.com/watch/\(cleanQuery.replacingOccurrences(of: " ", with: "-"))-explained",
                description: "Watch our video series that breaks down \(query) into easy-to-understand concepts. Perfect for beginners and experts alike."
            )
        )
        
        // Result 5: Academic resource
        results.append(
            SearchResult(
                title: "Academic Papers on \(query.capitalized) - Research Database",
                url: "https://academic.example.com/research/\(cleanQuery.replacingOccurrences(of: " ", with: "_"))",
                description: "Access peer-reviewed academic papers and research studies about \(query). Our database includes resources from top universities and research institutions."
            )
        )
        
        return results
    }
    
    private func generateAISummary(for query: String, results: [SearchResult]) -> String {
        // Create a simulated AI summary based on the query and results
        return """
        Based on search results for "\(query)", it appears to be a topic with both academic and practical applications. Multiple reliable sources provide information about it, including encyclopedia entries, news articles, and educational resources. The concept seems to be well-documented with explanatory guides and video content available. For more detailed information, academic research papers are also accessible through specialized databases.
        """
    }
}

// MARK: - Script to Movie Feature

struct ScriptToMovieView: View {
    @StateObject private var viewModel = ScriptToMovieViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var script = ""
    @State private var styleSelection = "Animated"
    
    let styles = ["Animated", "Realistic", "Cartoon", "Sketch", "3D"]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    Text("AI Script to Movie")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("Enter a script and convert it into a short movie")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                    
                    VStack(alignment: .leading) {
                        Text("Script")
                            .font(.headline)
                        
                        TextEditor(text: $script)
                            .frame(minHeight: 200)
                            .padding(4)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                            )
                        
                        Text("\(script.count) characters")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)
                    
                    VStack(alignment: .leading) {
                        Text("Visual Style")
                            .font(.headline)
                        
                        Picker("Style", selection: $styleSelection) {
                            ForEach(styles, id: \.self) { style in
                                Text(style).tag(style)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                    .padding(.horizontal)
                    
                    Button(action: {
                        viewModel.generateMovie(from: script, style: styleSelection)
                    }) {
                        HStack {
                            if viewModel.isGenerating {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .padding(.trailing, 5)
                            } else {
                                Image(systemName: "film")
                            }
                            Text(viewModel.isGenerating ? "Generating..." : "Create Movie")
                        }
                        .frame(minWidth: 200)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(script.count < 50 || viewModel.isGenerating)
                    
                    if viewModel.isGenerating {
                        VStack {
                            ProgressView(value: viewModel.generationProgress)
                                .padding(.horizontal)
                            
                            Text("\(Int(viewModel.generationProgress * 100))% - \(viewModel.generationStatusMessage)")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }
                    }
                    
                    if let videoURL = viewModel.generatedVideoURL {
                        VStack {
                            Text("Your movie is ready!")
                                .font(.headline)
                                .foregroundColor(.green)
                            
                            VideoPlayer(player: AVPlayer(url: videoURL))
                                .frame(height: 200)
                                .cornerRadius(8)
                                .padding(.horizontal)
                            
                            HStack {
                                Button(action: {
                                    viewModel.saveVideoToPhotos()
                                }) {
                                    HStack {
                                        Image(systemName: "square.and.arrow.down")
                                        Text("Save")
                                    }
                                    .frame(minWidth: 100)
                                    .padding()
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                }
                                
                                Button(action: {
                                    viewModel.shareVideo()
                                }) {
                                    HStack {
                                        Image(systemName: "square.and.arrow.up")
                                        Text("Share")
                                    }
                                    .frame(minWidth: 100)
                                    .padding()
                                    .background(Color.orange)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                }
                            }
                        }
                    }
                    
                    if !viewModel.errorMessage.isEmpty {
                        Text(viewModel.errorMessage)
                            .foregroundColor(.red)
                            .padding()
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .alert(isPresented: $viewModel.showingAlert) {
                Alert(
                    title: Text(viewModel.alertTitle),
                    message: Text(viewModel.alertMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
            .navigationBarItems(leading: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                }
            })
        }
    }
}

class ScriptToMovieViewModel: ObservableObject {
    @Published var isGenerating = false
    @Published var generationProgress: Double = 0
    @Published var generationStatusMessage = "Initializing"
    @Published var generatedVideoURL: URL?
    @Published var errorMessage = ""
    @Published var showingAlert = false
    @Published var alertTitle = ""
    @Published var alertMessage = ""
    
    private let scriptToMovieService = ScriptToMovieService()
    
    func generateMovie(from script: String, style: String) {
        guard !script.isEmpty else {
            errorMessage = "Please enter a script"
            return
        }
        
        isGenerating = true
        generationProgress = 0
        errorMessage = ""
        generatedVideoURL = nil
        
        scriptToMovieService.generateMovie(from: script, style: style) { [weak self] progress, status in
            DispatchQueue.main.async {
                self?.generationProgress = progress
                self?.generationStatusMessage = status
            }
        } completion: { [weak self] result in
            DispatchQueue.main.async {
                self?.isGenerating = false
                
                switch result {
                case .success(let videoURL):
                    self?.generatedVideoURL = videoURL
                case .failure(let error):
                    self?.errorMessage = "Generation failed: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func saveVideoToPhotos() {
        guard let url = generatedVideoURL else {
            showAlert(title: "Error", message: "No video to save")
            return
        }
        
        scriptToMovieService.saveVideoToPhotos(url: url) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.showAlert(title: "Save Error", message: error.localizedDescription)
                } else {
                    self?.showAlert(title: "Success", message: "Video saved to your photo library")
                }
            }
        }
    }
    
    func shareVideo() {
        guard let url = generatedVideoURL else {
            showAlert(title: "Error", message: "No video to share")
            return
        }
        
        scriptToMovieService.shareVideo(url: url)
    }
    
    private func showAlert(title: String, message: String) {
        alertTitle = title
        alertMessage = message
        showingAlert = true
    }
}

class ScriptToMovieService {
    enum ScriptToMovieError: Error {
        case invalidScript
        case processingFailed
        case fileWriteFailed
        case networkError
        
        var localizedDescription: String {
            switch self {
            case .invalidScript:
                return "The script is invalid or too short."
            case .processingFailed:
                return "Failed to process the script into a movie."
            case .fileWriteFailed:
                return "Failed to save the generated movie file."
            case .networkError:
                return "Network connection error. Please check your internet connection."
            }
        }
    }
    
    // In a real implementation, this would use an actual API key from environment variables
    private let apiKey = APIKeys.scriptToMovieAPI
    
    func generateMovie(from script: String, style: String, progressHandler: @escaping (Double, String) -> Void, completion: @escaping (Result<URL, ScriptToMovieError>) -> Void) {
        // Validate script
        guard !script.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, script.count >= 50 else {
            completion(.failure(.invalidScript))
            return
        }
        
        // For demo purposes, we'll simulate the API call and generation process
        // In a real implementation, this would make an actual API request to a script-to-movie service
        simulateMovieGeneration(script: script, style: style, progressHandler: progressHandler, completion: completion)
    }
    
    func saveVideoToPhotos(url: URL, completion: @escaping (Error?) -> Void) {
        // In a real implementation, this would use PHPhotoLibrary to save the video
        // For demo purposes, we'll simulate saving the video
        DispatchQueue.global().asyncAfter(deadline: .now() + 1.0) {
            completion(nil) // Simulate successful save
        }
    }
    
    func shareVideo(url: URL) {
        // In a real implementation, this would present a UIActivityViewController
        // For Swift Playgrounds, this would need different handling
        // For demo purposes, we're just declaring this method
    }
    
    // MARK: - Private Simulation Methods
    
    private func simulateMovieGeneration(script: String, style: String, progressHandler: @escaping (Double, String) -> Void, completion: @escaping (Result<URL, ScriptToMovieError>) -> Void) {
        // Define generation stages
        let stages = [
            "Analyzing script",
            "Generating storyboard",
            "Creating character models",
            "Rendering scenes",
            "Adding special effects",
            "Generating audio",
            "Finalizing video"
        ]
        
        // Simulate generation process with progress updates
        var currentStage = 0
        var progress: Double = 0.0
        
        // Progress update timer
        let timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { timer in
            // Update progress
            progress += Double.random(in: 0.02...0.06)
            let cappedProgress = min(progress, 0.98) // Cap at 98% until complete
            
            // Update current stage if needed
            let expectedStage = min(Int(cappedProgress * Double(stages.count)), stages.count - 1)
            if expectedStage > currentStage {
                currentStage = expectedStage
            }
            
            // Report progress
            progressHandler(cappedProgress, stages[currentStage])
            
            // If we've reached the end of simulation
            if progress >= 1.0 {
                timer.invalidate()
            }
        }
        
        // Simulate completion after delay
        DispatchQueue.global().asyncAfter(deadline: .now() + 8.0) {
            timer.invalidate()
            progressHandler(1.0, "Complete")
            
            // Generate a dummy video file URL
            if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                let videoFilename = "generated_movie_\(Int(Date().timeIntervalSince1970)).mp4"
                let videoFileURL = documentsDirectory.appendingPathComponent(videoFilename)
                
                // Simulate file creation (in a real app, we would write actual video data)
                // Here, we're just pretending the file exists
                completion(.success(videoFileURL))
            } else {
                completion(.failure(.fileWriteFailed))
            }
        }
    }
}

// MARK: - Hair Removal Feature

struct HairRemovalView: View {
    @StateObject private var viewModel = HairRemovalViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var showingImagePicker = false
    @State private var intensity: Double = 0.5
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    Text("AI Hair Removal")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Text("Upload a photo to remove unwanted hair using AI")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                    
                    if viewModel.inputImage != nil {
                        Image(uiImage: viewModel.inputImage!)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .cornerRadius(10)
                            .padding()
                    } else {
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 200)
                            
                            VStack {
                                Image(systemName: "photo")
                                    .font(.system(size: 40))
                                Text("No Image Selected")
                                    .font(.headline)
                            }
                            .foregroundColor(.gray)
                        }
                        .padding()
                    }
                    
                    Button(action: {
                        showingImagePicker = true
                    }) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                            Text(viewModel.inputImage == nil ? "Select Photo" : "Change Photo")
                        }
                        .frame(minWidth: 200)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    if viewModel.inputImage != nil {
                        VStack(alignment: .leading) {
                            Text("Removal Intensity: \(Int(intensity * 100))%")
                                .font(.headline)
                            
                            Slider(value: $intensity, in: 0.1...1.0, step: 0.1)
                                .padding(.vertical)
                            
                            Button(action: {
                                viewModel.processImage(intensity: intensity)
                            }) {
                                HStack {
                                    if viewModel.isProcessing {
                                        ProgressView()
                                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                            .padding(.trailing, 5)
                                    } else {
                                        Image(systemName: "wand.and.stars")
                                    }
                                    Text(viewModel.isProcessing ? "Processing..." : "Remove Hair")
                                }
                                .frame(minWidth: 200)
                                .padding()
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                            }
                            .disabled(viewModel.isProcessing)
                        }
                        .padding()
                    }
                    
                    if viewModel.resultImage != nil {
                        VStack {
                            Text("Result")
                                .font(.headline)
                            
                            Image(uiImage: viewModel.resultImage!)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 200)
                                .cornerRadius(10)
                                .padding()
                            
                            HStack {
                                Button(action: {
                                    viewModel.saveResultImage()
                                }) {
                                    HStack {
                                        Image(systemName: "square.and.arrow.down")
                                        Text("Save")
                                    }
                                    .frame(minWidth: 100)
                                    .padding()
                                    .background(Color.orange)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                }
                                
                                Button(action: {
                                    viewModel.shareImage()
                                }) {
                                    HStack {
                                        Image(systemName: "square.and.arrow.up")
                                        Text("Share")
                                    }
                                    .frame(minWidth: 100)
                                    .padding()
                                    .background(Color.purple)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                }
                            }
                        }
                    }
                    
                    if !viewModel.errorMessage.isEmpty {
                        Text(viewModel.errorMessage)
                            .foregroundColor(.red)
                            .padding()
                    }
                    
                    Spacer()
                }
                .padding()
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(image: $viewModel.inputImage)
            }
            .alert(isPresented: $viewModel.showingAlert) {
                Alert(
                    title: Text(viewModel.alertTitle),
                    message: Text(viewModel.alertMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
            .navigationBarItems(leading: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                }
            })
        }
    }
}

class HairRemovalViewModel: ObservableObject {
    @Published var inputImage: UIImage?
    @Published var resultImage: UIImage?
    @Published var isProcessing = false
    @Published var errorMessage = ""
    @Published var showingAlert = false
    @Published var alertTitle = ""
    @Published var alertMessage = ""
    
    private let hairRemovalService = HairRemovalService()
    
    func processImage(intensity: Double) {
        guard let image = inputImage else {
            errorMessage = "No image selected"
            return
        }
        
        isProcessing = true
        errorMessage = ""
        
        hairRemovalService.removeHair(from: image, intensity: intensity) { [weak self] result in
            DispatchQueue.main.async {
                self?.isProcessing = false
                
                switch result {
                case .success(let processedImage):
                    self?.resultImage = processedImage
                case .failure(let error):
                    self?.errorMessage = "Processing failed: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func saveResultImage() {
        guard let image = resultImage else {
            showAlert(title: "Error", message: "No result image to save")
            return
        }
        
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveCompleted), nil)
    }
    
    @objc func saveCompleted(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            showAlert(title: "Save Error", message: error.localizedDescription)
        } else {
            showAlert(title: "Saved", message: "Image has been saved to your photos")
        }
    }
    
    func shareImage() {
        guard let image = resultImage else {
            showAlert(title: "Error", message: "No result image to share")
            return
        }
        
        hairRemovalService.shareImage(image)
    }
    
    private func showAlert(title: String, message: String) {
        alertTitle = title
        alertMessage = message
        showingAlert = true
    }
}

class HairRemovalService {
    enum HairRemovalError: Error {
        case invalidImage
        case processingFailed
        case apiError(String)
        case networkError
        
        var localizedDescription: String {
            switch self {
            case .invalidImage:
                return "The image is invalid or corrupted."
            case .processingFailed:
                return "Failed to process the image."
            case .apiError(let message):
                return "API Error: \(message)"
            case .networkError:
                return "Network connection error. Please check your internet connection."
            }
        }
    }
    
    // In a real implementation, this would use an actual API key from environment variables
    private let apiKey = APIKeys.hairRemovalAPI
    
    func removeHair(from image: UIImage, intensity: Double, completion: @escaping (Result<UIImage, HairRemovalError>) -> Void) {
        // Compress and convert the image to base64
        guard let imageData = image.jpegData(compressionQuality: 0.7) else {
            completion(.failure(.invalidImage))
            return
        }
        
        let base64Image = imageData.base64EncodedString()
        
        // For demo purposes, we'll simulate the API call and return a processed version of the input image
        // In a real implementation, this would make an actual API request to a hair removal service
        simulateAPICall(originalImage: image, base64Image: base64Image, intensity: intensity, completion: completion)
    }
    
    func shareImage(_ image: UIImage) {
        // In a real implementation, this would present a UIActivityViewController
        // For Swift Playgrounds, this would need different handling
        // For demo purposes, we're just declaring this method
    }
    
    private func simulateAPICall(originalImage: UIImage, base64Image: String, intensity: Double, completion: @escaping (Result<UIImage, HairRemovalError>) -> Void) {
        // Simulate network delay
        DispatchQueue.global().asyncAfter(deadline: .now() + 2.0) {
            // For demonstration purposes, apply a filter to simulate hair removal
            if let processedImage = self.applyHairRemovalFilter(to: originalImage, intensity: intensity) {
                completion(.success(processedImage))
            } else {
                completion(.failure(.processingFailed))
            }
        }
    }
    
    private func applyHairRemovalFilter(to image: UIImage, intensity: Double) -> UIImage? {
        // This is a simplified simulation of hair removal
        // Real implementation would use the API response
        
        // Create a CIImage from the UIImage
        guard let ciImage = CIImage(image: image) else { return nil }
        
        // Apply a combination of filters to simulate hair removal
        // Step 1: Apply smoothing based on intensity
        let smoothingFilter = CIFilter(name: "CIHighlightShadowAdjust")
        smoothingFilter?.setValue(ciImage, forKey: kCIInputImageKey)
        smoothingFilter?.setValue(0.7 + (intensity * 0.3), forKey: "inputHighlightAmount")
        smoothingFilter?.setValue(1.0, forKey: "inputShadowAmount")
        
        guard let smoothedImage = smoothingFilter?.outputImage else { return nil }
        
        // Step 2: Apply subtle sharpening for edges
        let sharpenFilter = CIFilter(name: "CISharpenLuminance")
        sharpenFilter?.setValue(smoothedImage, forKey: kCIInputImageKey)
        sharpenFilter?.setValue(intensity * 0.5, forKey: "inputSharpness")
        
        guard let finalCIImage = sharpenFilter?.outputImage else { return nil }
        
        // Convert CIImage to UIImage
        let context = CIContext()
        guard let cgImage = context.createCGImage(finalCIImage, from: finalCIImage.extent) else { return nil }
        
        return UIImage(cgImage: cgImage)
    }
}

// MARK: - SwiftUI Preview

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// This plays the app when run directly
@main
struct AIMultiToolPlaygroundApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}