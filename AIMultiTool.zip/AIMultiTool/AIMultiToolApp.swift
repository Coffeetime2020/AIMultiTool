import SwiftUI

@main
struct AIMultiToolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
