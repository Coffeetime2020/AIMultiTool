// Content of AIMultiToolApp.swift
import SwiftUI

@main
struct AIMultiToolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
